using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Authorization;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllersWithViews(options =>
{
    // Global Authorize filtresi (her yer koruma alt�nda)
    var policy = new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .Build();
    options.Filters.Add(new AuthorizeFilter(policy));
});

builder.Services.AddHttpClient();

// Cookie Authentication yap�land�rmas�
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/SignIn/Index";          // Giri� yap�lmad�ysa buraya y�nlendir
        options.LogoutPath = "/SignIn/SignOut";       // ��k�� yolu
        options.AccessDeniedPath = "/Pages/AccessDenied"; // Yetkisiz eri�im sayfas�
        options.Cookie.Name = "CarBookAuthCookie";
        options.Cookie.HttpOnly = true;               // G�venlik
        options.Cookie.SameSite = SameSiteMode.Strict;
        options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
        options.SlidingExpiration = true;             // Kullan�c� aktifse oturum s�resi yenilenir
        options.ExpireTimeSpan = TimeSpan.FromMinutes(60); // Oturum s�resi
    });

builder.Services.AddAuthorization();

//builder.Services.AddControllersWithViews();
//builder.Services.AddHttpClient();

//builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddCookie(JwtBearerDefaults.AuthenticationScheme, opt =>
//{
//    opt.LoginPath = "/SignIn/Index";
//    opt.LogoutPath = "/SignIn/SignOut";
//    opt.AccessDeniedPath = "/Pages/AccessDenied";
//    opt.Cookie.SameSite = SameSiteMode.Strict;
//    opt.Cookie.HttpOnly = true;
//    opt.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
//    opt.Cookie.Name = "CarBookAuthCookie";    
//});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllerRoute(
    name: "areas",
    pattern: "{area:exists}/{controller=Home}/{action=Index}/{id?}");

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Default}/{action=Index}/{id?}");

app.Run();
