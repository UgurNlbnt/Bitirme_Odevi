﻿using CarBook.DTO.BlogDtos;
using CarBook.DTO.BrandDtos;
using CarBook.DTO.TagCloudDto;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Text;

namespace CarBook.WebUI.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class TagCloudController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public TagCloudController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.pageTitle = "Etiket Bulutu";

            // List TagClouds
            using var client = _httpClientFactory.CreateClient();
            var responseMessage = await client.GetAsync("https://localhost:7146/api/TagClouds/GetTagCloudWithBlogs");
            if (responseMessage.IsSuccessStatusCode)
            {
                var jsonData = await responseMessage.Content.ReadAsStringAsync();
                var values = JsonConvert.DeserializeObject<List<ResultTagCloudWithBlogsDto>>(jsonData);
                return View(values);
            }

            return View();
        }

        [HttpGet]
        public async Task<IActionResult> CreateTagCloud()
        {
            ViewBag.pageTitle = "Etiket Bulutu";

            // List Blogs
            using var client = _httpClientFactory.CreateClient();
            var responseMessage = await client.GetAsync("https://localhost:7146/api/Blogs");
            if (responseMessage.IsSuccessStatusCode)
            {
                var jsonData = await responseMessage.Content.ReadAsStringAsync();
                var values = JsonConvert.DeserializeObject<List<ResultBlogWithAuthorDto>>(jsonData);
                List<SelectListItem> blogs = (from x in values
                                               select new SelectListItem
                                               {
                                                   Text = x.Title,
                                                   Value = x.BlogId.ToString()
                                               }).ToList();

                ViewBag.Blogs = blogs;
            }

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateTagCloud(CreateTagCloudDto dto)
        {
            using var client = _httpClientFactory.CreateClient();
            var jsonData = JsonConvert.SerializeObject(dto);
            StringContent stringContent = new StringContent(jsonData, Encoding.UTF8, "application/json");
            var responseMessage = await client.PostAsync("https://localhost:7146/api/TagClouds", stringContent);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            return View();
        }

        public async Task<IActionResult> RemoveTagCloud(int id)
        {
            using var client = _httpClientFactory.CreateClient();
            var responseMessage = await client.DeleteAsync($"https://localhost:7146/api/TagClouds/{id}");
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            return View();
        }

        [HttpGet]
        public async Task<IActionResult> UpdateTagCloud(int id)
        {
            ViewBag.pageTitle = "Etiket Bulutu";

            using var client = _httpClientFactory.CreateClient();

            // List Blogs
            var responseMessage2 = await client.GetAsync("https://localhost:7146/api/Blogs");
            if (responseMessage2.IsSuccessStatusCode)
            {
                var jsonData2 = await responseMessage2.Content.ReadAsStringAsync();
                var values2 = JsonConvert.DeserializeObject<List<ResultBlogWithAuthorDto>>(jsonData2);
                List<SelectListItem> blogs = (from x in values2
                                              select new SelectListItem
                                              {
                                                  Text = x.Title,
                                                  Value = x.BlogId.ToString()
                                              }).ToList();

                ViewBag.Blogs = blogs;
            }

            // Get TagCloud By Id
            var responseMessage = await client.GetAsync($"https://localhost:7146/api/TagClouds/{id}");
            if (responseMessage.IsSuccessStatusCode)
            {
                var jsonData = await responseMessage.Content.ReadAsStringAsync();
                var value = JsonConvert.DeserializeObject<UpdateTagCloudDto>(jsonData);
                return View(value);
            }

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UpdateTagCloud(UpdateTagCloudDto dto)
        {
            using var client = _httpClientFactory.CreateClient();
            var jsonData = JsonConvert.SerializeObject(dto);
            StringContent stringContent = new StringContent(jsonData, Encoding.UTF8, "application/json");
            var responseMessage = await client.PutAsync("https://localhost:7146/api/TagClouds", stringContent);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            return View();
        }
    }
}
