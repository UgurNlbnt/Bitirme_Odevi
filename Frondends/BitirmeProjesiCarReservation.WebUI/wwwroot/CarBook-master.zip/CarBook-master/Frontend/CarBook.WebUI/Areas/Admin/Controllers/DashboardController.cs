﻿using CarBook.DTO.CarDtos;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using System.Threading.Tasks;

namespace CarBook.WebUI.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class DashboardController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public DashboardController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.pageTitle = "Dashboard";


            List<AverageDailyPriceByBrandDto> brandPrices = new();
            List<CarFuelDistributionDto> fuelDistribution = new();

            var client = _httpClientFactory.CreateClient();

            // Ortalama fiyat verisi
            var response1 = await client.GetAsync("https://localhost:7146/api/Cars/GetAverageDailyPriceByBrand");
            if (response1.IsSuccessStatusCode)
            {
                var jsonData = await response1.Content.ReadAsStringAsync();
                brandPrices = JsonConvert.DeserializeObject<List<AverageDailyPriceByBrandDto>>(jsonData);
            }

            // Yakıt türü dağılım verisi
            var response2 = await client.GetAsync("https://localhost:7146/api/Cars/GetCarCountByFuel");
            if (response2.IsSuccessStatusCode)
            {
                var jsonData2 = await response2.Content.ReadAsStringAsync();
                fuelDistribution = JsonConvert.DeserializeObject<List<CarFuelDistributionDto>>(jsonData2);
            }

            ViewBag.FuelDistribution = fuelDistribution;

            return View(brandPrices);
        }
    }
}
