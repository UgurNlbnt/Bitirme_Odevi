﻿using CarBook.DTO.BrandDtos;
using CarBook.DTO.CarDescriptionDtos;
using CarBook.DTO.CarDtos;
using CarBook.DTO.CarFeatureDtos;
using CarBook.DTO.FeatureDto;
using CarBook.DTO.LocationDtos;
using Humanizer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.WebUI.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class CarController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public CarController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.pageTitle = "Arabalar";

            // List Cars With Brand
            using var client = _httpClientFactory.CreateClient();
            var responseMessage = await client.GetAsync("https://localhost:7146/api/Cars/GetCarWithBrand");
            if (responseMessage.IsSuccessStatusCode)
            {
                var jsonData =  await responseMessage.Content.ReadAsStringAsync();
                var values = JsonConvert.DeserializeObject<List<ResultCarWithBrandDto>>(jsonData);
                return View(values);
            }

            return View();
        }

        [HttpGet]
        public async Task<IActionResult> CreateCar()
        {
            ViewBag.pageTitle = "Arabalar";

            using var client = _httpClientFactory.CreateClient();

            // --- Markalar ---
            var brandResponse = await client.GetAsync("https://localhost:7146/api/Brands");
            if (brandResponse.IsSuccessStatusCode)
            {
                var jsonData = await brandResponse.Content.ReadAsStringAsync();
                var brandValues = JsonConvert.DeserializeObject<List<ResultBrandDto>>(jsonData);

                List<SelectListItem> brands = brandValues
                    .Select(x => new SelectListItem
                    {
                        Text = x.Name,
                        Value = x.BrandId.ToString()
                    })
                    .ToList();

                ViewBag.Brands = brands;
            }

            // --- Lokasyonlar ---
            var locationResponse = await client.GetAsync("https://localhost:7146/api/Locations");
            if (locationResponse.IsSuccessStatusCode)
            {
                var jsonData = await locationResponse.Content.ReadAsStringAsync();
                var locationValues = JsonConvert.DeserializeObject<List<ResultLocationDto>>(jsonData);

                List<SelectListItem> locations = locationValues
                    .Select(x => new SelectListItem
                    {
                        Text = x.Name,
                        Value = x.LocationId.ToString()
                    })
                    .ToList();

                ViewBag.Locations = locations;
            }

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateCar(CreateCarDto dto)
        {
            using var client = _httpClientFactory.CreateClient();
            var jsonData = JsonConvert.SerializeObject(dto);
            StringContent stringContent = new StringContent(jsonData, Encoding.UTF8, "application/json");
            var responseMessage = await client.PostAsync("https://localhost:7146/api/Cars", stringContent);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            return View();
        }

        public async Task<IActionResult> RemoveCar(int id)
        {
            using var client = _httpClientFactory.CreateClient();
            var responseMessage = await client.DeleteAsync($"https://localhost:7146/api/Cars/{id}");
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            return View();
        }

        [HttpGet]
        public async Task<IActionResult> UpdateCar(int id)
        {
            ViewBag.pageTitle = "Arabalar";

            using var client = _httpClientFactory.CreateClient();

            // --- Markalar ---
            var brandResponse = await client.GetAsync("https://localhost:7146/api/Brands");
            if (brandResponse.IsSuccessStatusCode)
            {
                var jsonData = await brandResponse.Content.ReadAsStringAsync();
                var brandValues = JsonConvert.DeserializeObject<List<ResultBrandDto>>(jsonData);

                List<SelectListItem> brands = brandValues
                    .Select(x => new SelectListItem
                    {
                        Text = x.Name,
                        Value = x.BrandId.ToString()
                    })
                    .ToList();

                ViewBag.Brands = brands;
            }

            // --- Lokasyonlar ---
            var locationResponse = await client.GetAsync("https://localhost:7146/api/Locations");
            if (locationResponse.IsSuccessStatusCode)
            {
                var jsonData = await locationResponse.Content.ReadAsStringAsync();
                var locationValues = JsonConvert.DeserializeObject<List<ResultLocationDto>>(jsonData);

                List<SelectListItem> locations = locationValues
                    .Select(x => new SelectListItem
                    {
                        Text = x.Name,
                        Value = x.LocationId.ToString()
                    })
                    .ToList();

                ViewBag.Locations = locations;
            }

            // Get Car By Id            
            var responseMessage = await client.GetAsync($"https://localhost:7146/api/Cars/{id}");
            if (responseMessage.IsSuccessStatusCode)
            {
                var jsonData = await responseMessage.Content.ReadAsStringAsync();
                var value = JsonConvert.DeserializeObject<UpdateCarDto>(jsonData);
                return View(value);
            }           

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UpdateCar(UpdateCarDto dto)
        {
            using var client = _httpClientFactory.CreateClient();
            var jsonData = JsonConvert.SerializeObject(dto);
            StringContent stringContent = new StringContent(jsonData, Encoding.UTF8, "application/json");
            var responseMessage = await client.PutAsync("https://localhost:7146/api/Cars", stringContent);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            return View();
        }

        [HttpGet]
        public async Task<IActionResult> CarFeatures(int id)
        {
            ViewBag.pageTitle = "Araba Özellikleri";

            using var client = _httpClientFactory.CreateClient();
            var response = await client.GetAsync($"https://localhost:7146/api/CarFeature/GetCarFeaturesByCarId/{id}");        

            if (response.IsSuccessStatusCode)
            {
                var jsonData = await response.Content.ReadAsStringAsync();
                var values = JsonConvert.DeserializeObject<List<ResultCarFeatureByCarIdDto>>(jsonData);
                return View(values);
            }

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CarFeatures(int carId, List<ResultCarFeatureByCarIdDto> features)
        {
            using var client = _httpClientFactory.CreateClient();
            var json = JsonConvert.SerializeObject(new
            {
                CarId = carId,
                Features = features
            }); // JSON içinde CarId ve Features gönderiyoruz

            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync("https://localhost:7146/api/CarFeature/UpdateCarFeaturesByCarId", content);

            if (response.IsSuccessStatusCode)
            {
                TempData["Success"] = "Özellikler başarıyla güncellendi!";
                return RedirectToAction("Index");
                //return RedirectToAction("CarFeatures", new { id = carId });
            }

            TempData["Error"] = "Güncelleme sırasında bir hata oluştu.";
            return View(features);
        }

        [HttpGet]
        public async Task<IActionResult> CarDescription(int id)
        {
            ViewBag.pageTitle = "Araba Açıklaması";

            using var client = new HttpClient(); // veya IHttpClientFactory kullan
            var response = await client.GetAsync($"https://localhost:7146/api/CarDescription/GetCarDescriptionByCarId/{id}");

            if (response.IsSuccessStatusCode)
            {
                var jsonData = await response.Content.ReadAsStringAsync();
                var value = JsonConvert.DeserializeObject<GetCarDescriptionByCarIdDto>(jsonData);
                return View(value);
            }

            return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> CarDescription(GetCarDescriptionByCarIdDto dto)
        {
            // API için command oluştur
            var command = new UpdateCarDescriptionDto
            {
                CarId = dto.CarId,
                Details = dto.Details
            };

            // JSON serialize
            var json = JsonConvert.SerializeObject(command);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            // API PUT isteği
            using var client = new HttpClient(); // veya IHttpClientFactory
            var response = await client.PutAsync("https://localhost:7146/api/CarDescription/UpdateCarDescription", content);

            if (response.IsSuccessStatusCode)
            {
                TempData["Success"] = "Açıklama başarıyla güncellendi!";
                return RedirectToAction("CarDescription", new { id = dto.CarId });
            }

            TempData["Error"] = "Güncelleme sırasında hata oluştu.";
            return View(dto);
        }
    }
}
