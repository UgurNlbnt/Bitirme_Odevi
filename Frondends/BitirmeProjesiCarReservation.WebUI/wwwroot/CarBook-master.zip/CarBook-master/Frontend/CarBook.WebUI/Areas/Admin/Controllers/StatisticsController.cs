﻿using CarBook.DTO.StatisticsDtos;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;

namespace CarBook.WebUI.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class StatisticsController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public StatisticsController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.pageTitle = "İstatistikler";        
            string statisticsApiBaseUrl = "https://localhost:7146/api/Statistics/";

            ViewBag.CarCount = await GetValueAsync<int>(statisticsApiBaseUrl + "GetCarCount", "carCount");
            ViewBag.AuthorCount = await GetValueAsync<int>(statisticsApiBaseUrl + "GetAuthorCount", "authorCount");
            ViewBag.AvgRentPriceForDaily = await GetValueAsync<decimal>(statisticsApiBaseUrl + "GetAvgRentPriceForDaily", "avgRentPriceForDaily");
            ViewBag.AvgRentPriceForHourly = await GetValueAsync<decimal>(statisticsApiBaseUrl + "GetAvgRentPriceForHourly", "avgRentPriceForHourly");
            ViewBag.AvgRentPriceForWeekly = await GetValueAsync<decimal>(statisticsApiBaseUrl + "GetAvgRentPriceForWeekly", "avgRentPriceForWeekly");
            ViewBag.BlogCount = await GetValueAsync<int>(statisticsApiBaseUrl + "GetBlogCount", "blogCount");
            ViewBag.BlogTitleByMaxBlogComment = await GetValueAsync<string>(statisticsApiBaseUrl + "GetBlogTitleByMaxBlogComment", "blogTitle");
            ViewBag.BrandCount = await GetValueAsync<int>(statisticsApiBaseUrl + "GetBrandCount", "brandCount");
            ViewBag.BrandNameByMaxCar = await GetValueAsync<string>(statisticsApiBaseUrl + "GetBrandNameByMaxCar", "brandNameByMaxCar");
            ViewBag.CarBrandAndModelByRentPriceDailyMax = await GetValueAsync<string>(statisticsApiBaseUrl + "GetCarBrandAndModelByRentPriceDailyMax", "carBrandAndModelByRentPriceDailyMax");
            ViewBag.CarBrandAndModelByRentPriceDailyMin = await GetValueAsync<string>(statisticsApiBaseUrl + "GetCarBrandAndModelByRentPriceDailyMin", "carBrandAndModelByRentPriceDailyMin");
            ViewBag.CarCountByAutoTransmission = await GetValueAsync<int>(statisticsApiBaseUrl + "GetCarCountByAutoTransmission", "carCountByAutoTransmission");
            ViewBag.CarCountByFuelElectricity = await GetValueAsync<int>(statisticsApiBaseUrl + "GetCarCountByFuelElectricity", "carCountByFuelElectricity");
            ViewBag.CarCountByFuelGasolineOrDiesel = await GetValueAsync<int>(statisticsApiBaseUrl + "GetCarCountByFuelGasolineOrDiesel", "carCountByFuelGasolineOrDiesel");
            ViewBag.CarCountByLessThan1000Kms = await GetValueAsync<int>(statisticsApiBaseUrl + "GetCarCountByLessThan1000Kms", "carCountByLessThan1000Kms");
            ViewBag.LocationCount = await GetValueAsync<int>(statisticsApiBaseUrl + "GetLocationCount", "locationCount");

            return View();
        }

        private async Task<T> GetValueAsync<T>(string url, string propertyName)
        {
            var client = _httpClientFactory.CreateClient();
            var response = await client.GetAsync(url);
            var json = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode || string.IsNullOrWhiteSpace(json))
                return default;

            var obj = JsonConvert.DeserializeObject<dynamic>(json);
            return (T)obj[propertyName];
        }
    }
}


// ResultStatisticsDto kullanımı yerine ViewBag ile direkt controller'da verileri çekip view'a gönderme yapıldı.

//public async Task<IActionResult> Index()
//{
//    ViewBag.pageTitle = "İstatistikler";
//    string statisticsApiBaseUrl = "https://localhost:7146/api/Statistics/";

//    var client = _httpClientFactory.CreateClient();
//    var response = await client.GetAsync(statisticsApiBaseUrl + "GetAllStatistics"); // API'de tüm istatistikleri dönen endpoint
//    if (!response.IsSuccessStatusCode)
//        return View(); // veya hata handling

//    var json = await response.Content.ReadAsStringAsync();
//    var statistics = JsonConvert.DeserializeObject<ResultStatisticsDto>(json);

//    // Artık ViewBag yerine tek bir DTO kullanabiliriz
//    return View(statistics);
//}