﻿using CarBook.DTO.ReservationDtos;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace CarBook.WebUI.ViewComponents.AdminDashboardViewComponents
{
    public class _Get5PopularCarAdminDashboardComponent : ViewComponent
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public _Get5PopularCarAdminDashboardComponent(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            var client = _httpClientFactory.CreateClient();

            // 1. Popüler 5 aracı alıyoruz
            var response = await client.GetAsync("https://localhost:7146/api/Reservations/GetTop5PopularCars");
            if (!response.IsSuccessStatusCode)
                return View(new List<ResultPopularCarDto>());

            var jsonData = await response.Content.ReadAsStringAsync();
            var popularCars = JsonConvert.DeserializeObject<List<ResultPopularCarDto>>(jsonData);

            // 2. Her araç için detay bilgilerini çekiyoruz
            foreach (var car in popularCars)
            {
                var detailResponse = await client.GetAsync($"https://localhost:7146/api/Cars/GetCarDetail/{car.CarId}");
                if (detailResponse.IsSuccessStatusCode)
                {
                    var detailJson = await detailResponse.Content.ReadAsStringAsync();
                    dynamic carDetail = JsonConvert.DeserializeObject(detailJson);

                    car.Brand = carDetail.brandName?.ToString();
                    car.Model = carDetail.model?.ToString();
                    car.Fuel = carDetail.fuel?.ToString();
                    car.Transmission = carDetail.transmission?.ToString();
                    car.CoverImageUrl = carDetail.coverImageUrl?.ToString();
                    car.Km = carDetail.km?.ToString();
                    car.Seat = carDetail.seat?.ToString();
                    car.Luggage = carDetail.luggage?.ToString();
                }
            }

            return View(popularCars);
        }
    }
}
