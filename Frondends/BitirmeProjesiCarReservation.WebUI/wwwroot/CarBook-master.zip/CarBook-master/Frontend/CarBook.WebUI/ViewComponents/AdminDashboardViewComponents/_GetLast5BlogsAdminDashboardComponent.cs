﻿using CarBook.DTO.BlogDtos;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace CarBook.WebUI.ViewComponents.AdminDashboardViewComponents
{
    public class _GetLast5BlogsAdminDashboardComponent : ViewComponent
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public _GetLast5BlogsAdminDashboardComponent(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            List<ResultLast5BlogsDto> values = new();

            var client = _httpClientFactory.CreateClient();

            var response = await client.GetAsync("https://localhost:7146/api/Blogs/GetLast5Blogs");
            if (response.IsSuccessStatusCode)
            {
                var jsonData = await response.Content.ReadAsStringAsync();
                values = JsonConvert.DeserializeObject<List<ResultLast5BlogsDto>>(jsonData);

                foreach (var item in values)
                {
                    var commentResponse = await client.GetAsync($"https://localhost:7146/api/Comments/GetCommentCountByBlogId/{item.BlogId}");
                    if (commentResponse.IsSuccessStatusCode)
                    {
                        var commentJson = await commentResponse.Content.ReadAsStringAsync();

                        var obj = JObject.Parse(commentJson);
                        item.CommentCount = (int)(obj["commentCountByBlogId"] ?? 0);
                    }
                }
            }

            return View(values);
        }
    }
}
