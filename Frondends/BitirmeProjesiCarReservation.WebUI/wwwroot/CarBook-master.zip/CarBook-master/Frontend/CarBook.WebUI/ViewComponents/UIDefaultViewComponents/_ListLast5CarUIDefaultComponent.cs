﻿using CarBook.DTO.BannerDtos;
using CarBook.DTO.CarDtos;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace CarBook.WebUI.ViewComponents.UIDefaultViewComponents
{
    public class _ListLast5CarUIDefaultComponent : ViewComponent
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public _ListLast5CarUIDefaultComponent(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            using var client = _httpClientFactory.CreateClient();
            var responseMessage = await client.GetAsync("https://localhost:7146/api/Cars/GetLast5CarsWithBrand");

            if (responseMessage.IsSuccessStatusCode)
            {
                var jsonData = await responseMessage.Content.ReadAsStringAsync();
                var values = JsonConvert.DeserializeObject<List<ResultLast5CarWtihBrandDto>>(jsonData);
                return View(values);
            }

            return View();
        }
    }
}
