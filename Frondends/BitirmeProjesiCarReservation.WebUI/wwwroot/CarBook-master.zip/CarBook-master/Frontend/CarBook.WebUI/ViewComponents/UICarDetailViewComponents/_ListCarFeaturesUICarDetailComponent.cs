﻿using CarBook.DTO.CarFeatureDtos;
using CarBook.DTO.CommentDtos;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace CarBook.WebUI.ViewComponents.UICarDetailViewComponents
{
    public class _ListCarFeaturesUICarDetailComponent : ViewComponent
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public _ListCarFeaturesUICarDetailComponent(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IViewComponentResult> InvokeAsync(int id)
        {
            using var client = _httpClientFactory.CreateClient();
            var response = await client.GetAsync($"https://localhost:7146/api/CarFeature/GetCarFeaturesByCarId/{id}");

            if (response.IsSuccessStatusCode)
            {
                var jsonData = await response.Content.ReadAsStringAsync();
                var values = JsonConvert.DeserializeObject<List<ResultCarFeatureByCarIdDto>>(jsonData);
                return View(values);
            }

            return View();
        }
    }
}
