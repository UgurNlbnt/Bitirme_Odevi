﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;

namespace CarBook.WebUI.ViewComponents.AdminDashboardViewComponents
{
    public class _StatisticsAdminDashboardComponent : ViewComponent
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public _StatisticsAdminDashboardComponent(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            string statisticsApiBaseUrl = "https://localhost:7146/api/Statistics/";

            var client = _httpClientFactory.CreateClient();

            var carCount = await GetValueAsync<int>(client, statisticsApiBaseUrl + "GetCarCount", "carCount");
            var avgDaily = await GetValueAsync<decimal>(client, statisticsApiBaseUrl + "GetAvgRentPriceForDaily", "avgRentPriceForDaily");
            var autoCount = await GetValueAsync<int>(client, statisticsApiBaseUrl + "GetCarCountByAutoTransmission", "carCountByAutoTransmission");
            var electricCount = await GetValueAsync<int>(client, statisticsApiBaseUrl + "GetCarCountByFuelElectricity", "carCountByFuelElectricity");

            ViewBag.CarCount = carCount;
            ViewBag.AvgRentPriceForDaily = avgDaily;
            ViewBag.CarCountByAutoTransmission = autoCount;
            ViewBag.CarCountByFuelElectricity = electricCount;

            return View();
        }

        private async Task<T> GetValueAsync<T>(HttpClient client, string url, string propertyName)
        {
            var response = await client.GetAsync(url);
            if (!response.IsSuccessStatusCode) return default;

            var json = await response.Content.ReadAsStringAsync();
            var obj = JsonConvert.DeserializeObject<dynamic>(json);
            return (T)obj[propertyName];
        }
    }
}
