﻿using CarBook.DTO.StatisticsDtos;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace CarBook.WebUI.ViewComponents.UIDefaultViewComponents
{
    public class _Get4StatisticUIDefaultComponent : ViewComponent
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public _Get4StatisticUIDefaultComponent(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            string url = "https://localhost:7146/api/Statistics/";
            using var client = _httpClientFactory.CreateClient();
            var result = new ResultUIStatisticsDto();

            // 1️ Araba sayısı
            var response1 = await client.GetAsync(url + "GetCarCount");
            if (response1.IsSuccessStatusCode)
            {
                var json1 = await response1.Content.ReadAsStringAsync();
                var obj1 = JObject.Parse(json1);
                result.TotalCarCount = (int)obj1["carCount"];
            }

            // 2️ Elektrikli araba sayısı
            var response2 = await client.GetAsync(url + "GetCarCountByFuelElectricity");
            if (response2.IsSuccessStatusCode)
            {
                var json2 = await response2.Content.ReadAsStringAsync();
                var obj2 = JObject.Parse(json2);
                result.TotalElectricCarCount = (int)obj2["carCountByFuelElectricity"];
            }

            // 3️ Marka sayısı
            var response3 = await client.GetAsync(url + "GetBrandCount");
            if (response3.IsSuccessStatusCode)
            {
                var json3 = await response3.Content.ReadAsStringAsync();
                var obj3 = JObject.Parse(json3);
                result.TotalBrandCount = (int)obj3["brandCount"];
            }

            // 4️ Lokasyon sayısı
            var response4 = await client.GetAsync(url + "GetLocationCount");
            if (response4.IsSuccessStatusCode)
            {
                var json4 = await response4.Content.ReadAsStringAsync();
                var obj4 = JObject.Parse(json4);
                result.TotalLocationCount = (int)obj4["locationCount"];
            }

            return View(result);
        }
    }
}
