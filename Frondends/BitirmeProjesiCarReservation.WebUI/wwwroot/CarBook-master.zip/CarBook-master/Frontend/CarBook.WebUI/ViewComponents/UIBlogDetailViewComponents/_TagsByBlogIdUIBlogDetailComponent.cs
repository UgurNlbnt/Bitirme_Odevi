﻿using CarBook.DTO.CategoryDtos;
using CarBook.DTO.TagCloudDto;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace CarBook.WebUI.ViewComponents.UIBlogDetailViewComponents
{
    public class _TagsByBlogIdUIBlogDetailComponent : ViewComponent
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public _TagsByBlogIdUIBlogDetailComponent(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IViewComponentResult> InvokeAsync(int id)
        {
            using var client = _httpClientFactory.CreateClient();
            var responseMessage = await client.GetAsync($"https://localhost:7146/api/TagClouds/GetTagCloudByBlogId/{id}");

            if (responseMessage.IsSuccessStatusCode)
            {
                var jsonData = await responseMessage.Content.ReadAsStringAsync();
                var values = JsonConvert.DeserializeObject<List<ResultTagCloudByBlogIdDto>>(jsonData);
                return View(values);
            }

            return View();
        }
    }
}
