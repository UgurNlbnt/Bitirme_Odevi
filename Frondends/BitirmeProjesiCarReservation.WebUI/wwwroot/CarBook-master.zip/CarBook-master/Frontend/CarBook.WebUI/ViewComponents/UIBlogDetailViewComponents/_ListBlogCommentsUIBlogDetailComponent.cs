﻿using CarBook.DTO.CommentDtos;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace CarBook.WebUI.ViewComponents.UIBlogDetailViewComponents
{
    public class _ListBlogCommentsUIBlogDetailComponent : ViewComponent
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public _ListBlogCommentsUIBlogDetailComponent(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }       

        public async Task<IViewComponentResult> InvokeAsync(int blogId)
        {
            using var client = _httpClientFactory.CreateClient();
                       
            var response = await client.GetAsync($"https://localhost:7146/api/Comments/GetCommentByBlogId/{blogId}");

            if (!response.IsSuccessStatusCode)
            {
                return View();
            }

            var jsonData = await response.Content.ReadAsStringAsync();
            var comments = JsonConvert.DeserializeObject<List<ResultCommentByBlogIdDto>>(jsonData);

            return View(comments);
        }
    }
}
