﻿using CarBook.DTO.CarDescriptionDtos;
using CarBook.DTO.CarFeatureDtos;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace CarBook.WebUI.ViewComponents.UICarDetailViewComponents
{
    public class _GetCarDescriptionUICarDetailComponent : ViewComponent
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public _GetCarDescriptionUICarDetailComponent(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IViewComponentResult> InvokeAsync(int id)
        {
            using var client = _httpClientFactory.CreateClient();
            var response = await client.GetAsync($"https://localhost:7146/api/CarDescription/GetCarDescriptionByCarId/{id}");

            if (response.IsSuccessStatusCode)
            {
                var jsonData = await response.Content.ReadAsStringAsync();
                var value = JsonConvert.DeserializeObject<GetCarDescriptionByCarIdDto>(jsonData);
                return View(value);
            }

            return View();
        }
    }
}
