﻿using CarBook.DTO.BlogDtos;
using CarBook.DTO.CommentDtos;
using CarBook.WebUI.Models;
using Humanizer;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using System.Threading.Tasks;

namespace CarBook.WebUI.Controllers
{
    public class BlogController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public BlogController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IActionResult> Index()
        {       
            ViewBag.homepage = "Ana Sayfa";
            ViewBag.homepageurl = "/Default/Index";
            ViewBag.currentPageB = "BLOG";
            ViewBag.currentPageS = "Bloglarımız";

            using var client = _httpClientFactory.CreateClient();
            var responseMessage = await client.GetAsync("https://localhost:7146/api/Blogs/GetBlogWithAuthor");

            if (responseMessage.IsSuccessStatusCode)
            {
                var jsonData = await responseMessage.Content.ReadAsStringAsync();
                var blogs = JsonConvert.DeserializeObject<List<ResultBlogWithAuthorDto>>(jsonData);

                // 🔹 Her blog için yorum sayısını çekelim
                foreach (var blog in blogs)
                {
                    var commentResponse = await client.GetAsync($"https://localhost:7146/api/Comments/GetCommentCountByBlogId/{blog.BlogId}");
                    if (commentResponse.IsSuccessStatusCode)
                    {
                        var countJson = await commentResponse.Content.ReadAsStringAsync();

                        // ⬇️ Düzgün şekilde deserialize edelim
                        var countObj = JsonConvert.DeserializeObject<ResultCommentCountDto>(countJson);
                        var commentCount = countObj?.CommentCountByBlogId ?? 0;

                        ViewData[$"CommentCount_{blog.BlogId}"] = commentCount;
                    }
                }

                return View(blogs);
            }

            return View();

            //ViewBag.homepage = "Ana Sayfa";
            //ViewBag.homepageurl = "/Default/Index";
            //ViewBag.currentPageB = "BLOG";
            //ViewBag.currentPageS = "Bloglarımız";

            //// Blog With Author API Consume
            //using var client = _httpClientFactory.CreateClient();
            //var responseMessage = await client.GetAsync("https://localhost:7146/api/Blogs/GetBlogWithAuthor");

            //if (responseMessage.IsSuccessStatusCode)
            //{
            //    var jsonData = await responseMessage.Content.ReadAsStringAsync();
            //    var values = JsonConvert.DeserializeObject<List<ResultBlogWithAuthorDto>>(jsonData);
            //    return View(values);
            //}

            //return View();
        }

        public async Task<IActionResult> GetBlogById(int id)
        {
            ViewBag.homepage = "Ana Sayfa";
            ViewBag.homepageurl = "/Default/Index";
            ViewBag.currentPageB = "BLOG DETAYI";
            ViewBag.currentPageS = "Blog Detayını İncele";
            ViewBag.blogId = id;

            ResultBlogByIdWithAuthorDto blog = null;

            // Get Blog By Id With Author API Consume
            using var client = _httpClientFactory.CreateClient();
            var responseMessage = await client.GetAsync($"https://localhost:7146/api/Blogs/GetBlogByIdWithAuthor?id={id}");

            if (responseMessage.IsSuccessStatusCode)
            {
                var jsonData = await responseMessage.Content.ReadAsStringAsync();
                blog = JsonConvert.DeserializeObject<ResultBlogByIdWithAuthorDto>(jsonData);
                return View(blog);
            }

            return View();
        }                

        [HttpPost]
        public async Task<IActionResult> CreateComment(CreateCommentDto dto)
        {
            dto.CreatedDate = DateTime.Now;
            using var client = _httpClientFactory.CreateClient();
            var jsonData = JsonConvert.SerializeObject(dto);
            var content = new StringContent(jsonData, System.Text.Encoding.UTF8, "application/json");
            var response = await client.PostAsync("https://localhost:7146/api/Comments/", content);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("GetBlogById", new { id = dto.BlogId });
            }

            return RedirectToAction("GetBlogById", new { id = dto.BlogId });

        }
    }
}
