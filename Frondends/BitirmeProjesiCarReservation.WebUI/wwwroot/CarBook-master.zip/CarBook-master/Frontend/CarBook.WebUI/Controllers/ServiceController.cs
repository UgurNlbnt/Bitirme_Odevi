﻿using CarBook.DTO.ServiceDtos;
using CarBook.DTO.TestimonialDtos;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace CarBook.WebUI.Controllers
{
    public class ServiceController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public ServiceController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.homepage = "Ana Sayfa";
            ViewBag.homepageurl = "/Default/Index";
            ViewBag.currentPageB = "HİZMETLERİMİZ";
            ViewBag.currentPageS = "Hizmetlerimiz";

            return View();                   
        }
    }
}
