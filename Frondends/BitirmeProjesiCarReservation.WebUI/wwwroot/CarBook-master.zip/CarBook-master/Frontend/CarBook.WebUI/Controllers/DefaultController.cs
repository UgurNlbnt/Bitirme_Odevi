﻿using CarBook.DTO.CarDtos;
using CarBook.DTO.LocationDtos;
using CarBook.DTO.ReservationDtos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System;
using System.Globalization;
using System.Net.Http.Headers;

namespace CarBook.WebUI.Controllers
{
    public class DefaultController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public DefaultController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IActionResult> Index()
        {
            // Jwt Authentication Kullanılmış Bölüm
            //var token = User.Claims.FirstOrDefault(x => x.Type == "accessToken")?.Value;
            //if (token != null)
            //{
            //    using var client = _httpClientFactory.CreateClient();

            //    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            //    var locationResponse = await client.GetAsync("https://localhost:7146/api/Locations");
            //    if (locationResponse.IsSuccessStatusCode)
            //    {
            //        var jsonData = await locationResponse.Content.ReadAsStringAsync();
            //        var locationValues = JsonConvert.DeserializeObject<List<ResultLocationDto>>(jsonData);

            //        List<SelectListItem> locations = locationValues
            //            .Select(x => new SelectListItem
            //            {
            //                Text = x.Name,
            //                Value = x.LocationId.ToString()
            //            })
            //            .ToList();

            //        ViewBag.Locations = locations;
            //    }
            //}            

            //return View();

            using var client = _httpClientFactory.CreateClient();
            var locationResponse = await client.GetAsync("https://localhost:7146/api/Locations");
            if (locationResponse.IsSuccessStatusCode)
            {
                var jsonData = await locationResponse.Content.ReadAsStringAsync();
                var locationValues = JsonConvert.DeserializeObject<List<ResultLocationDto>>(jsonData);

                List<SelectListItem> locations = locationValues
                    .Select(x => new SelectListItem
                    {
                        Text = x.Name,
                        Value = x.LocationId.ToString()
                    })
                    .ToList();

                ViewBag.Locations = locations;
            }

            return View();
        }

        [HttpPost]
        public IActionResult Index(ResultCarByFilterDto dto)
        {
            return RedirectToAction("BookACar", new
            {
                pickUpLocationId = dto.PickUpLocationId,
                dropOffLocationId = dto.DropOffLocationId,
                pickUpDate = dto.PickUpDate.ToString("yyyy-MM-dd"),
                dropOffDate = dto.DropOffDate.ToString("yyyy-MM-dd"),
                pickUpTime = dto.PickUpTime,
                dropOffTime = dto.DropOffTime
            });
        }

        [HttpGet]
        public async Task<IActionResult> BookACar([FromQuery] ReservationInfosDto dto)
        {
            ViewBag.homepage = "Ana Sayfa";
            ViewBag.homepageurl = "/Default/Index";
            ViewBag.currentPageB = "REZERVASYON";
            ViewBag.currentPageS = "Rezervasyonunuzu Yapın";
                        
            string formattedPickUpTime = "";
            string formattedDropOffTime = "";

            if (!string.IsNullOrEmpty(dto.PickUpTime))
            {
                DateTime pickTime = DateTime.ParseExact(dto.PickUpTime, "h:mmtt", System.Globalization.CultureInfo.InvariantCulture);
                formattedPickUpTime = pickTime.ToString("HH:mm");
            }

            if (!string.IsNullOrEmpty(dto.DropOffTime))
            {
                DateTime dropTime = DateTime.ParseExact(dto.DropOffTime, "h:mmtt", System.Globalization.CultureInfo.InvariantCulture);
                formattedDropOffTime = dropTime.ToString("HH:mm");
            }

            ViewBag.PickUpLocationId = dto.PickUpLocationId;
            ViewBag.DropOffLocationId = dto.DropOffLocationId;
            ViewBag.PickUpDate = dto.PickUpDate;
            ViewBag.DropOffDate = dto.DropOffDate;
            ViewBag.PickUpTime = formattedPickUpTime;
            ViewBag.DropOffTime = formattedDropOffTime;

            // Lokasyon adlarını çek
            using var client = _httpClientFactory.CreateClient();
            var pickResponse = await client.GetAsync($"https://localhost:7146/api/Locations/{dto.PickUpLocationId}");
            var dropResponse = await client.GetAsync($"https://localhost:7146/api/Locations/{dto.DropOffLocationId}");

            if (pickResponse.IsSuccessStatusCode)
            {
                var json = await pickResponse.Content.ReadAsStringAsync();
                var locationDto = JsonConvert.DeserializeObject<ResultLocationDto>(json);
                ViewBag.PickUpLocationName = locationDto.Name;
            }

            if (dropResponse.IsSuccessStatusCode)
            {
                var json = await dropResponse.Content.ReadAsStringAsync();
                var locationDto = JsonConvert.DeserializeObject<ResultLocationDto>(json);
                ViewBag.DropOffLocationName = locationDto.Name;
            }

            // Kullanıcının girdiği tarih - saati birleştir ve araçları çek                     

            var pickUpDateTime = DateTime.ParseExact($"{dto.PickUpDate}T{formattedPickUpTime}", "yyyy-MM-ddTHH:mm", CultureInfo.InvariantCulture);
            var dropOffDateTime = DateTime.ParseExact($"{dto.DropOffDate}T{formattedDropOffTime}", "yyyy-MM-ddTHH:mm", CultureInfo.InvariantCulture);

            string pickUpParam = Uri.EscapeDataString(pickUpDateTime.ToString("yyyy-MM-ddTHH:mm"));
            string dropOffParam = Uri.EscapeDataString(dropOffDateTime.ToString("yyyy-MM-ddTHH:mm"));

            var carsResponse = await client.GetAsync($"https://localhost:7146/api/Cars/GetCarsListByFilter/{dto.PickUpLocationId}/{pickUpParam}/{dropOffParam}");

            var carsJson = await carsResponse.Content.ReadAsStringAsync();
            var cars = JsonConvert.DeserializeObject<List<ResultCarWithPricingDto>>(carsJson);

            return View(cars);

        }

        [HttpGet]
        public IActionResult ConfirmReservation(int carId, [FromQuery] ReservationInfosDto dto)
        {
            ViewBag.homepage = "Ana Sayfa";
            ViewBag.homepageurl = "/Default/Index";
            ViewBag.currentPageB = "REZERVASYON";
            ViewBag.currentPageS = "Rezervasyonunuzu Tamamlayın";

            // ViewBag ile formda kullanılacak bilgileri taşı
            ViewBag.CarId = carId;
            ViewBag.PickUpLocationId = dto.PickUpLocationId;
            ViewBag.DropOffLocationId = dto.DropOffLocationId;
            ViewBag.PickUpDateTime = $"{dto.PickUpDate} {dto.PickUpTime}";
            ViewBag.DropOffDateTime = $"{dto.DropOffDate} {dto.DropOffTime}";

            //// API’den veya repository’den araba bilgilerini çek
            //var client = _httpClientFactory.CreateClient();
            //var carResponse = await client.GetAsync($"https://localhost:7146/api/Cars/{carId}");
            //if (carResponse.IsSuccessStatusCode)
            //{
            //    var carJson = await carResponse.Content.ReadAsStringAsync();
            //    var car = JsonConvert.DeserializeObject<ResultCarWithPricingDto>(carJson);
            //    ViewBag.CarBrand = car.Brand;
            //    ViewBag.CarModel = car.Model;
            //}

            //// API’den lokasyon isimlerini çek
            //var pickResponse = await client.GetAsync($"https://localhost:7146/api/Locations/{dto.PickUpLocationId}");
            //if (pickResponse.IsSuccessStatusCode)
            //{
            //    var pickJson = await pickResponse.Content.ReadAsStringAsync();
            //    var pickLocation = JsonConvert.DeserializeObject<ResultLocationDto>(pickJson);
            //    ViewBag.PickUpLocationName = pickLocation.Name;
            //}

            //var dropResponse = await client.GetAsync($"https://localhost:7146/api/Locations/{dto.DropOffLocationId}");
            //if (dropResponse.IsSuccessStatusCode)
            //{
            //    var dropJson = await dropResponse.Content.ReadAsStringAsync();
            //    var dropLocation = JsonConvert.DeserializeObject<ResultLocationDto>(dropJson);
            //    ViewBag.DropOffLocationName = dropLocation.Name;
            //}

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmReservation(CreateReservationDto dto)
        {
            dto.Status = "Onay Bekliyor";

            var client = _httpClientFactory.CreateClient();
            var jsonData = JsonConvert.SerializeObject(dto);
            var content = new StringContent(jsonData, System.Text.Encoding.UTF8, "application/json");

            var response = await client.PostAsync("https://localhost:7146/api/Reservations", content);

            if (response.IsSuccessStatusCode)
                return RedirectToAction("Index", "Default");
            else
                return View(dto);
        }
    }
}
