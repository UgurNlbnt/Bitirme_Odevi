﻿using Microsoft.AspNetCore.Mvc;

namespace CarBook.WebUI.Controllers
{
    public class AboutController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.homepage = "Ana Sayfa";
            ViewBag.homepageurl = "/Default/Index";
            ViewBag.currentPageB = "HAKKIMIZDA";
            ViewBag.currentPageS = "Hakkımızda";
            return View();
        }
    }
}
