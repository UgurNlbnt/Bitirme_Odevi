using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.DTO.CarDtos
{
    public class ResultCarWithPricingDto
    {
        public int CarId { get; set; }
        public int BrandId { get; set; }
        public string BrandName { get; set; }
        public string Model { get; set; }
        public string CoverImageUrl { get; set; }
        public string BigImageUrl { get; set; }
        public List<PricingDto> Pricings { get; set; }
    }

    public class PricingDto
    {
        public string PricingName { get; set; }
        public decimal PricingAmount { get; set; }
    }
}
