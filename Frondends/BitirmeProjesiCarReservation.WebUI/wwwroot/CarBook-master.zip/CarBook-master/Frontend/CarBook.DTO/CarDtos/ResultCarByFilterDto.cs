using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.DTO.CarDtos
{
    public class ResultCarByFilterDto
    {
        public int PickUpLocationId { get; set; }
        public int DropOffLocationId { get; set; }
        public string PickUpLocation { get; set; }
        public string DropOffLocation { get; set; }

        public DateTime PickUpDate { get; set; }
        public DateTime DropOffDate { get; set; }

        public string PickUpTime { get; set; }
        public string DropOffTime { get; set; }
    }
}
