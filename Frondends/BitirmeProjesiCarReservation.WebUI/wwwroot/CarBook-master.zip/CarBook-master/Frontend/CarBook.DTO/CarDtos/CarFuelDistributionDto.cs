using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.DTO.CarDtos
{
    public class CarFuelDistributionDto
    {
        public string Fuel { get; set; }
        public int Count { get; set; }
    }
}
