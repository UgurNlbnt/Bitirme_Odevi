using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.DTO.FeatureDto
{
    public class UpdateFeatureDto
    {
        public int FeatureId { get; set; }
        public string Name { get; set; }
    }
}
