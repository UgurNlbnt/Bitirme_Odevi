using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.DTO.StatisticsDtos
{
    public class ResultStatisticsDto
    {
        public int AuthorCount { get; set; }
        public decimal AvgRentPriceForDaily { get; set; }
        public decimal AvgRentPriceForHourly { get; set; }
        public decimal AvgRentPriceForWeekly { get; set; }
        public int BlogCount { get; set; }
        public string BlogCouBlogTitleByMaxBlogCommentnt { get; set; }
        public int BrandCount { get; set; }
        public string BrandNameByMaxCar { get; set; }
        public string CarBrandAndModelByRentPriceDailyMax { get; set; }
        public string CarBrandAndModelByRentPriceDailyMin { get; set; }
        public int CarCount { get; set; }
        public int CarCountByAutoTransmission { get; set; }
        public int CarCountByFuelElectricity { get; set; }
        public int CarCountByFuelGasolineOrDiesel { get; set; }
        public int CarCountByLessThan1000Kms { get; set; }
        public int LocationCount { get; set; }
    }
}
