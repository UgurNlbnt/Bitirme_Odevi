﻿using CarBook.Application.Features.CQRS.Results.CarResults;
using CarBook.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Interfaces.CarInterfaces
{
    public interface ICarRepository
    {
        Task<List<Car>> GetCarsListWithBrandAsync();

        Task<List<Car>> GetLast5CarsWithBrandAsync();

        Task<List<Car>> GetCarsListWithPricingAsync();

        Task<List<Car>> GetCarsListByFilterAsync(int pickUpLocationId, DateTime pickUpDate, DateTime dropOffDate);

        Task<Car> GetCarDetailAsync(int id);

        Task<List<GetAverageDailyPriceByBrandQueryResult>> GetAverageDailyPriceByBrandAsync();

        Task<List<GetCarCountByFuelQueryResult>> GetCarCountByFuelAsync();
    }
}
