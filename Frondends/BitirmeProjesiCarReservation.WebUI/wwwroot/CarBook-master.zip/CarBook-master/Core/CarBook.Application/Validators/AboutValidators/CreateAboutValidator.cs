using CarBook.Application.Features.CQRS.Commands.AboutCommands;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Validators.AboutValidators
{
    public class CreateAboutValidator : AbstractValidator<CreateAboutCommand>
    {
        public CreateAboutValidator()
        {
            RuleFor(x => x.Title).NotEmpty().WithMessage("Ba�l�k bo� ge�ilemez!");
            RuleFor(x => x.Description).NotEmpty().WithMessage("A��klama bo� ge�ilemez!");
            RuleFor(x => x.ImageUrl).NotEmpty().WithMessage("Resim Url'i bo� ge�ilemez!");
            RuleFor(x => x.Title).MinimumLength(5).WithMessage("Ba�l�k en az 5 karakter i�ermelidir!");
            RuleFor(x => x.Title).MaximumLength(100).WithMessage("Ba�l�k en fazla 100 karakter i�erebilir!");
            RuleFor(x => x.Description).MinimumLength(5).WithMessage("A��klama en az 5 karakter i�ermelidir!");
            RuleFor(x => x.Description).MaximumLength(100).WithMessage("A��klama en fazla 100 karakter i�erebilir!");
            RuleFor(x => x.ImageUrl).MinimumLength(5).WithMessage("Resim Url'i en az 5 karakter i�ermelidir!");
            RuleFor(x => x.ImageUrl).MaximumLength(100).WithMessage("Resim Url'i en fazla 100 karakter i�erebilir!");
        }
    }
}
