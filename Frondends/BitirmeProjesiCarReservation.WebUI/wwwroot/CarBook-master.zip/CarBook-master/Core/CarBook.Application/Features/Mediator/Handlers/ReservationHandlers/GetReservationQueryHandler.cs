using CarBook.Application.Features.Mediator.Queries.ReservationQueries;
using CarBook.Application.Features.Mediator.Results.ReservationResults;
using CarBook.Application.Interfaces.ReservationInterfaces;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Features.Mediator.Handlers.ReservationHandlers
{
    public class GetReservationQueryHandler : IRequestHandler<GetReservationQuery, List<GetReservationQueryResult>>
    {
        private readonly IReservationRepository _repository;

        public GetReservationQueryHandler(IReservationRepository repository)
        {
            _repository = repository;
        }

        public async Task<List<GetReservationQueryResult>> Handle(GetReservationQuery request, CancellationToken cancellationToken)
        {
            var values = await _repository.GetReservationsListWithCarAndLocationsName();

            return values.Select(x => new GetReservationQueryResult
            {
                Age = x.Age,
                CarBrand = x.Car.Brand.Name,
                CarId = x.CarId,
                CarModel = x.Car.Model,
                Description = x.Description,
                DrivingLicenceYear = x.DrivingLicenceYear,
                DropOffLocationId = x.DropOffLocationId,
                DropOffLocationName = x.DropOffLocation.Name,
                Email = x.Email,
                Name = x.Name,
                Surname = x.Surname,
                Phone = x.Phone,
                Status = x.Status,
                ReservationId = x.ReservationId,
                PickUpLocationId = x.PickUpLocationId,
                PickUpLocationName = x.PickUpLocation.Name,
                DropOffLocationDateTime = x.DropOffLocationDateTime,
                PickUpLocationDateTime = x.PickUpLocationDateTime
            }).ToList();
        }
    }
}
