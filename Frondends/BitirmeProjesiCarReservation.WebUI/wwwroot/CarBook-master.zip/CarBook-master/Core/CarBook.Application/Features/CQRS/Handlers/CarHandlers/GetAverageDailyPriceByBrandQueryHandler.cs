using CarBook.Application.Features.CQRS.Results.CarResults;
using CarBook.Application.Interfaces.CarInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Features.CQRS.Handlers.CarHandlers
{
    public class GetAverageDailyPriceByBrandQueryHandler
    {
        private readonly ICarRepository _repository;

        public GetAverageDailyPriceByBrandQueryHandler(ICarRepository repository)
        {
            _repository = repository;
        }

        public async Task<List<GetAverageDailyPriceByBrandQueryResult>> Handle()
        {
            return await _repository.GetAverageDailyPriceByBrandAsync();
        }
    }
}
