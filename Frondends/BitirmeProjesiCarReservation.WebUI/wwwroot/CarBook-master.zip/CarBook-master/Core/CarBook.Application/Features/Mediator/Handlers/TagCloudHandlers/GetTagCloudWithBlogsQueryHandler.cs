using CarBook.Application.Features.Mediator.Queries.TagCloudQueries;
using CarBook.Application.Features.Mediator.Results.TagCloudResults;
using CarBook.Application.Interfaces;
using CarBook.Application.Interfaces.TagCloudInterfaces;
using CarBook.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Features.Mediator.Handlers.TagCloudHandlers
{
    public class GetTagCloudWithBlogsQueryHandler : IRequestHandler<GetTagCloudWithBlogsQuery, List<GetTagCloudWithBlogsQueryResult>>
    {
        private readonly ITagCloudRepository _repository;

        public GetTagCloudWithBlogsQueryHandler(ITagCloudRepository repository)
        {
            _repository = repository;
        }               

        public async Task<List<GetTagCloudWithBlogsQueryResult>> Handle(GetTagCloudWithBlogsQuery request, CancellationToken cancellationToken)
        {
            var values = await _repository.GetListTagsWithBlogTitle();

            return values.Select(x => new GetTagCloudWithBlogsQueryResult
            {
                TagCloudId = x.TagCloudId,
                Title = x.Title,
                BlogId = x.BlogId,
                BlogTitle = x.Blog.Title

            }).ToList();
        }
    }
}
