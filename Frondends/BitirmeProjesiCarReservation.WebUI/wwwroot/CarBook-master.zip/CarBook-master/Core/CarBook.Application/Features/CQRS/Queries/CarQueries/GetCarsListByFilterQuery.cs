using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Features.CQRS.Queries.CarQueries
{
    public class GetCarsListByFilterQuery
    {
        public int LocationId { get; set; }
        public DateTime PickUpDateTime { get; set; }
        public DateTime DropOffDateTime { get; set; }

        public GetCarsListByFilterQuery(int locationId, DateTime pickUpDateTime, DateTime dropOffDateTime)
        {
            LocationId = locationId;
            PickUpDateTime = pickUpDateTime;
            DropOffDateTime = dropOffDateTime;
        }
    }
}
