using CarBook.Application.Features.Mediator.Queries.BlogQueries;
using CarBook.Application.Features.Mediator.Results.BlogResults;
using CarBook.Application.Interfaces;
using CarBook.Application.Interfaces.BlogInterfaces;
using CarBook.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Features.Mediator.Handlers.BlogHandlers
{
    public class GetBlogByIdWithAuthorQueryHandler : IRequestHandler<GetBlogByIdWithAuthorQuery, GetBlogByIdWithAuthorQueryResult>
    {
        private readonly IBlogRepository _repository;

        public GetBlogByIdWithAuthorQueryHandler(IBlogRepository repository)
        {
            _repository = repository;
        }

        public async Task<GetBlogByIdWithAuthorQueryResult> Handle(GetBlogByIdWithAuthorQuery request, CancellationToken cancellationToken)
        {
            var value = await _repository.GetBlogByIdWithAuthorAsync(request.Id);

            return new GetBlogByIdWithAuthorQueryResult
            {
                BlogId = value.BlogId,
                Title = value.Title,
                AuthorId = value.AuthorId,
                CategoryId = value.CategoryId,
                Detail = value.Detail,
                CreatedDate = value.CreatedDate,
                CoverImageUrl = value.CoverImageUrl,
                AuthorNameSurname = value.Author.NameSurname,
                AuthorImageUrl = value.Author.ImageUrl,
                AuthorDescription = value.Author.Description,
                CategoryName = value.Category.Name                
            };
        }
    }
}
