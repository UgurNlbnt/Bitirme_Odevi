using CarBook.Application.Features.Mediator.Commands.CarFeatureCommands;
using CarBook.Application.Interfaces.CarFeatureInterfaces;
using CarBook.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Features.Mediator.Handlers.CarFeatureHandlers
{
    public class UpdateCarFeaturesByCarIdCommandHandler : IRequestHandler<UpdateCarFeaturesByCarIdCommand, Unit>
    {
        private readonly ICarFeatureRepository _carFeatureRepository;

        public UpdateCarFeaturesByCarIdCommandHandler(ICarFeatureRepository carFeatureRepository)
        {
            _carFeatureRepository = carFeatureRepository;
        }

        public async Task<Unit> Handle(UpdateCarFeaturesByCarIdCommand request, CancellationToken cancellationToken)
        {
            var updatedFeatures = request.Features
                .Select(f => new CarFeature
                {
                    CarId = request.CarId,
                    FeatureId = f.FeatureId,
                    Available = f.Available
                })
                .ToList();

            await _carFeatureRepository.UpdateCarFeaturesAsync(request.CarId, updatedFeatures);
            return Unit.Value;
        }
    }
}
