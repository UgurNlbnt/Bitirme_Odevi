using CarBook.Application.Features.Mediator.Queries.CommentQueries;
using CarBook.Application.Features.Mediator.Results.CommentResults;
using CarBook.Application.Interfaces;
using CarBook.Application.Interfaces.CommentInterfaces;
using CarBook.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Features.Mediator.Handlers.CommentHandlers
{
    public class GetCommentByBlogIdQueryHandler : IRequestHandler<GetCommentByBlogIdQuery, List<GetCommentByBlogIdQueryResult>>
    {
        private readonly ICommentRepository _repository;

        public GetCommentByBlogIdQueryHandler(ICommentRepository repository)
        {
            _repository = repository;
        }

        async Task<List<GetCommentByBlogIdQueryResult>> IRequestHandler<GetCommentByBlogIdQuery, List<GetCommentByBlogIdQueryResult>>.Handle(GetCommentByBlogIdQuery request, CancellationToken cancellationToken)
        {
            var values = await _repository.GetCommentListByBlogIdAsync(request.BlogId);

            return values.Select(x => new GetCommentByBlogIdQueryResult
            {
                CommentId = x.CommentId,
                BlogId = x.BlogId,
                CommentDetail = x.CommentDetail,
                NameSurname = x.NameSurname,
                ImageUrl = x.ImageUrl,
                CreatedDate = x.CreatedDate,
                BlogTitle = x.Blog.Title
            }).ToList();
        }
    }
}
