using CarBook.Application.Features.CQRS.Results.CarResults;
using CarBook.Application.Interfaces.CarInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Features.CQRS.Handlers.CarHandlers
{
    public class GetCarCountByFuelQueryHandler
    {
        private readonly ICarRepository _carRepository;

        public GetCarCountByFuelQueryHandler(ICarRepository carRepository)
        {
            _carRepository = carRepository;
        }

        public async Task<List<GetCarCountByFuelQueryResult>> Handle()
        {
            var result = await _carRepository.GetCarCountByFuelAsync();
            return result;
        }
    }
}
