using CarBook.Application.Features.Mediator.Queries.BlogQueries;
using CarBook.Application.Features.Mediator.Results.BlogResults;
using CarBook.Application.Interfaces.BlogInterfaces;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Features.Mediator.Handlers.BlogHandlers
{
    public class GetLast5BlogQueryHandler : IRequestHandler<GetLast5BlogQuery, List<GetLast5BlogQueryResult>>
    {
        private readonly IBlogRepository _repository;

        public GetLast5BlogQueryHandler(IBlogRepository repository)
        {
            _repository = repository;
        }

        public async Task<List<GetLast5BlogQueryResult>> Handle(GetLast5BlogQuery request, CancellationToken cancellationToken)
        {
            var values = await _repository.GetLast5BlogsListAsync();

            return values.Select(x => new GetLast5BlogQueryResult
            {
                BlogId = x.BlogId,
                AuthorId = x.AuthorId,
                CategoryId = x.CategoryId,
                CoverImageUrl = x.CoverImageUrl,
                Detail = x.Detail,
                CreatedDate = x.CreatedDate,
                Title = x.Title,
                AuthorNameSurname = x.Author.NameSurname,
                CategoryName = x.Category.Name

            }).ToList();
        }
    }
}
