using CarBook.Application.Features.CQRS.Results;
using CarBook.Application.Features.CQRS.Results.CarResults;
using CarBook.Application.Interfaces.CarInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Features.CQRS.Handlers.CarHandlers
{
    public class GetCarWithPricingQueryHandler
    {
        private readonly ICarRepository _carRepository;

        public GetCarWithPricingQueryHandler(ICarRepository carRepository)
        {
            _carRepository = carRepository;
        }

        public async Task<List<GetCarWithPricingQueryResult>> Handle()
        {
            var values = await _carRepository.GetCarsListWithPricingAsync();

            return values.Select(x => new GetCarWithPricingQueryResult
            {
                CarId = x.CarId,
                BrandId = x.BrandId,
                BrandName = x.Brand.Name,
                BigImageUrl = x.BigImageUrl,
                CoverImageUrl = x.CoverImageUrl,                
                Model = x.Model,                
                Pricings = x.CarPricings.Select(p => new PricingDto
                {
                    PricingName = p.Pricing.Name,
                    PricingAmount = p.Amount
                }).ToList()                

            }).ToList();
        }
    }
}
