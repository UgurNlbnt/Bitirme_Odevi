using CarBook.Application.Features.Mediator.Commands.CarDescriptionCommands;
using CarBook.Application.Interfaces.CarDescriptionInterfaces;
using CarBook.Domain.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Features.Mediator.Handlers.CarDescriptionHandlers
{
    public class UpdateCarDescriptionCommandHandler : IRequestHandler<UpdateCarDescriptionCommand, bool>
    {
        private readonly ICarDescriptionRepository _repository;

        public UpdateCarDescriptionCommandHandler(ICarDescriptionRepository repository)
        {
            _repository = repository;
        }        

        async Task<bool> IRequestHandler<UpdateCarDescriptionCommand, bool>.Handle(UpdateCarDescriptionCommand request, CancellationToken cancellationToken)
        {
            var carDescription = new CarDescription
            {
                CarId = request.CarId,
                Details = request.Details
            };

            return await _repository.UpdateCarDescriptionAsync(carDescription);
        }
    }
}
