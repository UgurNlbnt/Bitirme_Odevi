using CarBook.Application.Features.CQRS.Results.CategoryResults;
using CarBook.Application.Interfaces;
using CarBook.Application.Interfaces.CategoryInterfaces;
using CarBook.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Features.CQRS.Handlers.CategoryHandlers
{
    public class GetCategoryWithBlogCountQueryHandler
    {
        private readonly ICategoryRepository _repository;

        public GetCategoryWithBlogCountQueryHandler(ICategoryRepository repository)
        {
            _repository = repository;
        }

        public async Task<List<GetCategoryWithBlogCountQueryResult>> Handle()
        {
            var values = await _repository.GetCategoryListWithBlogCountAsync();

            return values.Select(x => new GetCategoryWithBlogCountQueryResult
            {
                CategoryId = x.CategoryId,
                Name = x.Name,
                BlogCount = x.Blogs.Count
            }).ToList();
        }
    }
}
