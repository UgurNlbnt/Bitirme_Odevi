using CarBook.Application.Features.Mediator.Queries.ReservationQueries;
using CarBook.Application.Features.Mediator.Results.ReservationResults;
using CarBook.Application.Interfaces.ReservationInterfaces;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Features.Mediator.Handlers.ReservationHandlers
{
    public class GetTop5PopularCarsQueryHandler : IRequestHandler<GetTop5PopularCarsQuery, List<GetTop5PopularCarsQueryResult>>
    {
        private readonly IReservationRepository _reservationRepository;

        public GetTop5PopularCarsQueryHandler(IReservationRepository reservationRepository)
        {
            _reservationRepository = reservationRepository;
        }

        public async Task<List<GetTop5PopularCarsQueryResult>> Handle(GetTop5PopularCarsQuery request, CancellationToken cancellationToken)
        {
            var values = await _reservationRepository.GetTop5PopularCarsAsync();

            return values.Select(x => new GetTop5PopularCarsQueryResult
            {
                CarId = x.CarId,
                ReservationCount = x.ReservationCount
            }).ToList();
        }
    }
}
