using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Application.Enums
{
    public enum RoleType
    {
        Admin = 1,
        Member = 2,
        Visitor = 3,
        Manager = 4
    }
}
