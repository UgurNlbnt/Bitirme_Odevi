using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBook.Domain.Entities
{
    public class Reservation
    {
        public int ReservationId { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public int CarId { get; set; }
        public Car Car { get; set; }          
        public int Age { get; set; }
        public int DrivingLicenceYear { get; set; }
        public string? Description { get; set; } = "A��klama yok";
        public string Status { get; set; }
        public DateTime PickUpLocationDateTime { get; set; }
        public DateTime DropOffLocationDateTime { get; set; }
        public int PickUpLocationId { get; set; }
        public int DropOffLocationId { get; set; }
        public Location PickUpLocation { get; set; }
        public Location DropOffLocation { get; set; }
    }
}
